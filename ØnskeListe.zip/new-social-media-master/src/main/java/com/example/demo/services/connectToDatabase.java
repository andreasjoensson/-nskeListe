package com.example.demo.services;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


    public class connectToDatabase {
        public int insertIntoDatabaseAndGetID(String navn, String efternavn, String begivenhed, String ønske1, String ønske2, String ønske3, String ønske4, String ønske5) throws SQLException {
            Connection conn = null;
            try {
                conn = DriverManager.getConnection("jdbc:mysql://13.48.195.244:3306/Ønskeliste", "remote", "Oscar2019");
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            System.out.println("Forbundet til mysql databasen!");
            Statement mystmt = null;
            try {
                mystmt = conn.createStatement();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            String sql = "INSERT INTO `ønsker` (firstName, LastName, Begivenhed, Ønske1, Ønske2, Ønske3, Ønske4, Ønske5) VALUE ('"+navn+"','"+efternavn+"','"+begivenhed+"','"+ønske1+"','"+ønske2+"','"+ønske3+"','"+ønske4+"','"+ønske5+"')";
            PreparedStatement ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            System.out.println("stor success");
            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            int generatedKey = 0;
            if (rs.next()) {
                generatedKey = rs.getInt(1);
            }
            return generatedKey;
        }

    }
