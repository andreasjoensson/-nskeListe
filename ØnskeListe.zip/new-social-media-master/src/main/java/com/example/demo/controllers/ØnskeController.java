package com.example.demo.controllers;
import com.example.demo.services.connectToDatabase;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.ArrayList;

@Controller
public class ØnskeController {
    // LAV INSTANS AF DATABASE
    connectToDatabase DATABASE = new connectToDatabase();

    //OPRET ARRAYLIST
   ArrayList<onske> Ønsker = new ArrayList<onske>();

    @GetMapping(value = "/form")
    public String renderForm() {
        return "form";
    }

    @PostMapping(value = "/submit-post")
    public String createNewUser(@RequestParam("navn") String navn, @RequestParam("efternavn") String efternavn, @RequestParam("begivenhed") String begivenhed, @RequestParam("ønske1") String ønske1, @RequestParam("ønske2") String ønske2, @RequestParam("ønske3") String ønske3, @RequestParam("ønske4") String ønske4, @RequestParam("ønske5") String ønske5 ) throws SQLException {
        //OPRET TABEL MED DATA FRA HJEMMESIDE, SAMT GIV ET UNIKT ID
        int generatedKey = DATABASE.insertIntoDatabaseAndGetID(navn,efternavn,begivenhed,ønske1,ønske2,ønske3,ønske4,ønske5);

        //REDIRECT HEN TIL SUCCESS SIDE, OG VIDERGIV DET UNIKKE ID TIL AT FREMVISE DATA
        return new String("redirect:/success/" +generatedKey);
    }
    @GetMapping(value={"/success/{id}"})
    public String renderSuccess(Model model, @PathVariable String id) throws SQLException {
        //Opfanger unik ID fra URL

        //Opret forbindelse til DB
        Connection conn = DriverManager.getConnection("jdbc:mysql://xx/Ønskeliste", "remote", "xxx");
        System.out.println("Forbundet til mysql databasen!");

        //Lav specifik SQL Query til at få data fra tabel med unik ID
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ønsker WHERE id = '"+id+"';");
        ResultSet rs = stmt.executeQuery();

        //Så længe der er data i tabellen, vil den loop igennem de forskellige poster.
        while(rs.next()){
            model.addAttribute("firstname",rs.getString(2));
            model.addAttribute("lastname",rs.getString(3));
            model.addAttribute("begivenhed",rs.getString(4));
            model.addAttribute("onskeet",rs.getString(5));
            model.addAttribute("onsketo",rs.getString(6));
            model.addAttribute("onsketre",rs.getString(7));
            model.addAttribute("onskefire",rs.getString(8));
            model.addAttribute("onskefem",rs.getString(9));
        }
        onske ønske = new onske(model.getAttribute("firstname").toString(), model.getAttribute("lastname").toString(), model.getAttribute("begivenhed").toString(),model.getAttribute("onskeet").toString(),model.getAttribute("onsketo").toString(), model.getAttribute("onsketre").toString(), model.getAttribute("onskefire").toString(), model.getAttribute("onskefem").toString());
        Ønsker.add(ønske);
        return "success";
    }

    @GetMapping(value="/dashboard")
    public String renderDashboard(Model model) throws SQLException {
        model.addAttribute("onsker",Ønsker);
        return "dashboard.html";
    }
}
