package com.example.demo.controllers;

import java.io.Serializable;

    public class onske implements Serializable {
  String firstName;
  String lastName;
  String begivenhed;
  String ønske1;
  String ønske2;
  String ønske3;
  String ønske4;
  String ønske5;

 public onske(String firstname, String lastname, String begivenhed, String ønske1, String ønske2, String ønske3, String ønske4, String ønske5){
      this.firstName = firstname;
      this.lastName = lastname;
      this.begivenhed = begivenhed;
      this.ønske1 = ønske1;
      this.ønske2 = ønske2;
      this.ønske3 = ønske3;
      this.ønske4 = ønske4;
      this.ønske5 = ønske5;
  }


    @Override
    public String toString(){
      return "Post" + "firstname " + firstName + " lastname "
              + lastName + " begivenhed " + begivenhed + " ønske1 " + ønske1 + " ønske2 "
              + ønske2 + " ønske3 " + ønske3 + " ønske4 " + ønske4 + " ønske5 " + ønske5;
  }

}
